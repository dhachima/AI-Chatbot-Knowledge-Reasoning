# AI Chatbot with Knowledge-Based Reasoning
# Author: D. Sudharshini

rules = [
    {"if": ["fever", "cough"], "then": "flu"},
    {"if": ["fever", "rash"], "then": "measles"},
    {"if": ["tired", "sad"], "then": "stress"},
    {"if": ["headache", "nausea"], "then": "migraine"},
    {"if": ["fever", "joint_pain"], "then": "dengue"},
    {"if": ["sore_throat", "cough"], "then": "cold"}
]

def forward_chaining(facts, rules):
    inferred = []
    for rule in rules:
        if all(cond in facts for cond in rule["if"]):
            inferred.append(rule["then"])
    return inferred

def main():
    print("🤖 Welcome to AI Chatbot with Knowledge-Based Reasoning 🤖")
    print("Type 'exit' to quit.\nExample symptoms: fever, cough, rash, tired, sad, headache, nausea\n")
    while True:
        user_input = input("Enter your symptoms separated by space: ").lower().strip()
        if user_input == "exit":
            print("Goodbye! Stay healthy! 💪")
            break
        facts = user_input.replace(",", " ").split()
        result = forward_chaining(facts, rules)
        if result:
            print("Possible condition(s):", ", ".join(result))
        else:
            print("No matching condition found. Please consult a doctor.")
        print("----------------------------------------------------------\n")

if __name__ == '__main__':
    main()
