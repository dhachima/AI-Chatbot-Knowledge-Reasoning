# 🤖 AI Chatbot with Knowledge-Based Reasoning

This project implements an **AI-based chatbot** that uses **forward chaining** for knowledge-based reasoning.  
It demonstrates how expert systems can infer conclusions logically from user-provided facts.

## Features
- Rule-based Knowledge Representation  
- Forward Chaining Inference  
- Logical and Explainable Output  
- Implemented in Python 3.11.8

## How to Run
1. Clone or download this repository.
2. Ensure Python 3 is installed.
3. Run:
```
python chatbot.py
```

## Sample Input/Output
Input:
```
fever cough
```
Output:
```
Possible condition(s): flu
```

## Author
D. Sudharshini
